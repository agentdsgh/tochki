// server.js
//
// Шаг 6 плана: игра с ботом на уровне комнаты. При создании комнаты можно
// включить «Играть с ботом» — тогда место 2 сразу занимает бот (используя
// тот же chooseMove()/match.botMove() из gameEngine.js, что и в
// однопользовательской версии), и партия начинается без ожидания второго
// человека. Комнаты с ботом не участвуют в матчмейкинге и не принимают
// вход по коду (место 2 уже занято) — это защищённый одиночный сценарий
// «человек против бота», просто поверх той же сетевой инфраструктуры.
//
// Протокол (JSON-сообщения по WebSocket):
//   клиент -> сервер:
//     {type:'create-room', options:{sizeKey, targetScore, targetFillPercent,
//                                    extraTurnOnCapture, firstMove:'creator'|'opponent',
//                                    undoAllowed, vsBot, botDifficulty, isPublic}, authToken?}
//   undoAllowed (шаг 15) — разрешена ли отмена хода в этой партии; решает
//   создатель комнаты. По умолчанию true (как и раньше — отмена доступна
//   всем). Если false, request-undo для этой комнаты всегда отклоняется
//   с reason:'undo-disabled', а canUndo в снимке (см. getSnapshot) всегда
//   false — клиент прячет кнопку отмены сам, ориентируясь на это поле.
//   extraTurnOnCapture (шаг 13) — если true, игрок, чей ход привёл к
//   захвату (окружению) точки/точек соперника, ходит ещё раз, вместо
//   передачи хода сопернику. Применяется в Engine.createMatch — сервер
//   лишь пропускает флаг через sanitizeCreateOptions, вся логика в
//   gameEngine.js (applyMove: result.extraTurn) и в maybeTriggerBotMove
//   (бот ходит повторно сам, если его ход тоже дал захват).
//   firstMove (шаг 13) — кто ставит первую точку партии: 'creator'
//   (по умолчанию, как раньше) или 'opponent' (второй игрок/бот). Место 1
//   в серверной модели всегда закреплено за создателем комнаты, поэтому
//   выбор однозначно переводится в firstPlayer:1|2 для Engine.createMatch.
//   Не применяется к find-match (там нет понятия "создатель").
//     {type:'join-room', code, authToken?}
//     {type:'find-match', options:{sizeKey, targetScore, targetFillPercent}, authToken?}
//     {type:'cancel-find'}
//     {type:'reconnect', code, seat, token, authToken?}
//     {type:'move', x, y}
//     {type:'end'}
//     {type:'list-rooms'}                     — шаг 10: список открытых комнат для лобби
//     {type:'spectate-room', code}            — шаг 10: подключиться зрителем к открытой комнате
//     {type:'leave-room'}                     — немедленно освободить своё место/уйти из зрителей
//     {type:'rematch'}                        — шаг 10: сыграть ещё раз в той же комнате
//     {type:'request-undo'}                   — шаг 14: попросить отменить СВОЙ последний ход
//     {type:'undo-approve'}                   — шаг 14: согласиться на чужой запрос отмены
//     {type:'undo-decline'}                   — шаг 14: отклонить чужой запрос отмены
//   authToken — необязательный токен сессии из /api/login (не путать с
//   token переподключения к месту, который сервер сам генерирует и
//   присылает клиенту). Если валиден — сервер подставляет ник вместо
//   ника-заглушки "Индиго"/"Гранат" в playerNames.
//   сервер -> клиент:
//     {type:'room-created', code, seat, token, snapshot, vsBot, playerNames}  — только создателю
//     {type:'room-joined',  code, seat, token, snapshot, playerNames}        — только присоединившемуся
//     {type:'searching'}                             — встал в очередь
//     {type:'search-cancelled'}                      — вышел из очереди
//     {type:'match-found', code, seat, token, snapshot, playerNames}   — обоим сведённым игрокам
//     {type:'reconnected', code, seat, token, snapshot, vsBot, playerNames}  — успешно вернувшемуся
//     {type:'state', snapshot, playerNames, lastMove?, note?, extraTurn?}  — рассылается обоим (и зрителям);
//                                extraTurn:true — этот ход дал доп. ход (см. extraTurnOnCapture)
//     {type:'opponent-disconnected', seat, graceMs}  — оппонент отвалился, ждём
//     {type:'opponent-left', seat}                   — оппонент не вернулся — место освобождено
//     {type:'room-list', rooms:[{code, sizeKey, targetScore, targetFillPercent,
//                                 extraTurnOnCapture, status,
//                                 playerNames, spectatorCount}]}   — ответ на list-rooms
//     {type:'spectate-joined', code, snapshot, playerNames, vsBot}   — только зрителю
//     {type:'rematch-requested', seat}         — один из игроков предложил реванш, ждём второго
//     {type:'rematch-started', seat, token, snapshot, playerNames, vsBot}   — персонально каждому месту
//     (зрители получают ту же партию через обычный 'state' с новым snapshot)
//     {type:'undo-requested', seat}            — seat попросил отменить свой последний ход,
//                                                 ждём ответа второго игрока (шаг 14)
//     {type:'undo-declined', seat}             — запрос seat на отмену отклонён соперником
//     {type:'error', reason}
//
// Шаг 14 — отмена последнего хода по согласию соперника:
//   Отменить можно только САМЫЙ ПОСЛЕДНИЙ ход партии, и только тот игрок,
//   который его сделал (request-undo от кого-то другого отклоняется).
//   Пока запрос ждёт ответа, обоим ходить нельзя (см. 'move' → reason
//   'undo-pending') — иначе можно было бы согласиться отменить уже
//   неактуальный ход. Против бота согласие бота выставляется автоматически
//   (см. maybeAutoResolveUndo) — там нет живого второго игрока, которого
//   можно спросить. Откат восстанавливает доску/счёт/очередь целиком (см.
//   Engine.undoLastMove) — это касается только живого состояния партии в
//   памяти: сам ход остаётся в постоянном логе БД (gamelog), т.е.
//   GET /api/games/:code по-прежнему покажет отменённый ход как факт
//   истории, просто на доске его больше нет. Отмена хода, которым партия
//   уже завершилась (gameOver), недоступна — это осознанное решение (см.
//   обсуждение), как и то, что отмена сейчас не ограничена по количеству
//   и разрешена даже для хода, вызвавшего захват — оба пункта могут
//   измениться позже. Саму возможность отмены целиком для партии можно
//   выключить опцией undoAllowed:false при создании комнаты (см. выше).
//
// Шаг 10 — публичные комнаты, зрители и реванш:
//   При создании комнаты можно пометить её isPublic:true — тогда, пока в
//   ней свободно место (ждёт второго игрока) ИЛИ партия идёт, она попадает
//   в список list-rooms и её можно смотреть через spectate-room (только
//   просмотр состояния, зритель не может ходить). Комнаты с ботом и
//   приватные (isPublic:false, по умолчанию) в список не попадают.
//   Реванш: когда партия окончена (gameOver), любой из сидящих за столом
//   игроков может прислать 'rematch' — сервер ждёт согласия ВТОРОГО живого
//   игрока (если он ещё в комнате), затем создаёт новую партию с теми же
//   правилами в той же комнате (новая строка в games, тот же room_code).
//   Против бота реванш стартует сразу по одному запросу человека. Явное
//   'leave-room' освобождает место без ожидания reconnectGraceMs — чтобы
//   можно было сразу же уступить место другому игроку по тому же коду.
//
// Шаг 9 — логи партий и статистика (HTTP, не WS):
//   Каждая партия и каждый применённый ход (человека и бота) пишутся в
//   БД (см. gamelog.js) сразу по ходу дела — не пост-фактум и не только
//   при выигрыше. Игровая сессия в памяти (сокеты, таймеры реконнекта)
//   и её персистентный лог — разные вещи: комната пропадёт из памяти при
//   рестарте сервера, а её лог в БД останется.
//     GET  /api/games/:code        → {game, moves}   — сводка + все ходы по коду комнаты
//     GET  /api/stats/me           → {nickname, stats}         (нужен Authorization: Bearer)
//     GET  /api/stats/me/games?limit=20 → {games:[...]}        (нужен Authorization: Bearer)
//     GET  /api/stats/:nickname    → {nickname, stats}         — публично, без входа
//   stats = {gamesPlayed, wins, losses, draws, gamesVsBot, winRate}.
//   Только партии со статусом 'finished' входят в статистику — 'abandoned'
//   (комната брошена недоигранной) — нет.
//
// Шаг 11/12 — видимость БД и дообучения бота (HTTP, открыто, без входа):
//     GET  /api/admin/summary            → {totalGames, gamesByStatus, totalMoves,
//                                            totalUsers, botWeights:{normal,strong}}
//     GET  /api/bot/weights/:difficulty  → {difficulty, current, history}
//   Запуск дообучения (шаг 12) — уже НЕ открытый эндпоинт, нужен
//   ADMIN_TOKEN (см. README) и заголовок X-Admin-Token:
//     POST /api/admin/train  {difficulty?, generations?, population?, games?,
//                              sizeKey?, seed?}  → 202 {started, run}
//     GET  /api/admin/train  → {running, pid, params, startedAt, finishedAt,
//                                exitCode, ok, outputTail}
//   POST спавнит tools/train-bot.js ОТДЕЛЬНЫМ процессом (child_process.spawn)
//   и сразу отвечает — self-play никогда не считается в процессе сервера,
//   иначе завис бы event loop и вместе с ним — ходы живых игроков.
//
// Запуск:  npm install && npm start   (или PORT=3000 node server.js)
// Тест:    npm test

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');
const Engine = require('./gameEngine.js');
const { openDatabase, resolveDbPath } = require('./db.js');
const { createAuth } = require('./auth.js');
const { createGameLog } = require('./gamelog.js');
const TrainBot = require('./tools/train-bot.js');

const MAX_JSON_BODY_BYTES = 10 * 1024; // регистрация/вход — маленькие тела, больше не нужно

function readJsonBody(req){
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_JSON_BODY_BYTES){
        reject(Object.assign(new Error('payload-too-large'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e){ reject(Object.assign(new Error('bad-json'), { statusCode: 400 })); }
    });
    req.on('error', reject);
  });
}

function sendJson(res, statusCode, body){
  const data = JSON.stringify(body);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(data)
  });
  res.end(data);
}

// Без похожих друг на друга символов (0/O, 1/I/L), чтобы код было легко
// продиктовать или напечатать без ошибок.
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const CODE_LENGTH = 5;
// Если комната опустела (оба игрока отключились и не вернулись) — держим
// её ещё немного на случай, что кто-то просто перезагрузил страницу, потом
// удаляем. Это отдельный, более долгий таймаут поверх RECONNECT_GRACE_MS —
// он применяется уже ПОСЛЕ того, как оба места точно освободились навсегда.
const DEFAULT_EMPTY_ROOM_TTL_MS = 10 * 60 * 1000;
// Сколько времени даём отключившемуся игроку на переподключение, прежде
// чем окончательно освободить его место и аннулировать токен.
const DEFAULT_RECONNECT_GRACE_MS = 2 * 60 * 1000;

function generateToken(){
  return crypto.randomBytes(16).toString('hex');
}

// room = { code, match, seats:{1:ws|null,2:ws|null}, tokens:{1,2},
//          playerNames:{1,2}, playerUserIds:{1,2}, gameId, moveCount,
//          options, emptyTimer, graceTimers:{1:timer|null,2:timer|null},
//          vsBot, botSeat, botDifficulty,
//          isPublic, spectators:Set<ws>, rematchVotes:Set<seat>,
//          pendingUndo:{seat}|null }
function createRoomsRegistry(config){
  const emptyRoomTtlMs = config.emptyRoomTtlMs;
  const reconnectGraceMs = config.reconnectGraceMs;
  const rooms = new Map();

  function generateCode(){
    let code;
    do {
      code = '';
      for (let i=0; i<CODE_LENGTH; i++){
        code += CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)];
      }
    } while (rooms.has(code));
    return code;
  }

  function createRoom(options){
    const code = generateCode();
    const room = {
      code,
      match: Engine.createMatch(options || {}),
      seats: { 1: null, 2: null },
      tokens: { 1: null, 2: null },
      // Отображаемое имя для каждого места — ник из учётной записи, если
      // игрок вошёл (см. authToken в create-room/join-room/find-match/
      // reconnect), иначе null — тогда клиент сам показывает запасное имя
      // ("Индиго"/"Гранат"). Хранится на сервере (а не только в клиенте),
      // чтобы оппонент тоже видел настоящий ник, а не свой выдуманный.
      playerNames: { 1: null, 2: null },
      // id учётной записи для каждого места (или null для гостя/бота) —
      // именно по нему считается статистика в gamelog.js, ник для этого
      // не годится (его в будущем можно будет сменить).
      playerUserIds: { 1: null, 2: null },
      // id строки в таблице games (см. gamelog.js) — null, пока БД ещё не
      // подключена (createRoom используется и в тестах movegen-подобных
      // сценариев без сервера); в createServer() выставляется сразу же
      // после создания комнаты.
      gameId: null,
      // Порядковый номер следующего хода для записи в таблицу moves —
      // 0-based, растёт монотонно, независим от того, кто сходил.
      moveCount: 0,
      options: options || {},
      emptyTimer: null,
      graceTimers: { 1: null, 2: null },
      vsBot: false,
      botSeat: null,
      botDifficulty: null,
      // Шаг 10: комната видна в лобби (list-rooms) и доступна для просмотра
      // зрителями (spectate-room), только если создатель явно это включил.
      isPublic: false,
      spectators: new Set(),
      // Места (по номеру места), уже согласившиеся сыграть реванш в этой же
      // комнате — см. обработчик 'rematch'. Сбрасывается при старте новой
      // партии и при уходе игрока с места.
      rematchVotes: new Set(),
      // Шаг 14: запрос на отмену последнего хода, ожидающий ответа второго
      // игрока — {seat: <кто попросил>} | null. Живёт только между
      // 'request-undo' и его разрешением ('undo-approve'/'undo-decline'
      // или сброс места). Пока запрос висит, ходить нельзя (см. 'move') —
      // иначе можно было бы согласиться отменить уже неактуальный ход.
      pendingUndo: null
    };
    rooms.set(code, room);
    return room;
  }

  function getRoom(code){
    return rooms.get(String(code || '').toUpperCase());
  }

  // Место, занятое ботом, никогда не считается свободным для человека —
  // ни для входа по коду, ни (в принципе) для матчмейкинга.
  function freeSeat(room){
    if (!room.seats[1]) return 1;
    if (room.vsBot && room.botSeat === 2) return null;
    if (!room.seats[2]) return 2;
    return null;
  }

  function armEmptyTimer(room){
    if (room.emptyTimer) clearTimeout(room.emptyTimer);
    room.emptyTimer = setTimeout(() => {
      if (!room.seats[1] && !room.seats[2]){
        // Партия недоигранной комнаты, которую никто не забрал обратно,
        // помечается в БД как abandoned (не в статистику), прежде чем
        // сама комната пропадёт из памяти — иначе это "потерянная" партия,
        // которая навсегда останется висеть в статусе in_progress.
        if (config.onRoomExpired) config.onRoomExpired(room);
        rooms.delete(room.code);
      }
    }, emptyRoomTtlMs);
    // unref: этот таймер не должен сам по себе держать процесс живым
    // (иначе, например, скрипты тестов/graceful shutdown зависают).
    if (typeof room.emptyTimer.unref === 'function') room.emptyTimer.unref();
  }

  function disarmEmptyTimer(room){
    if (room.emptyTimer){ clearTimeout(room.emptyTimer); room.emptyTimer = null; }
  }

  // Место освобождается не сразу при разрыве связи, а даёт игроку
  // reconnectGraceMs на возврат с тем же токеном. Если не вернулся —
  // токен аннулируется, место освобождается окончательно.
  function armSeatGraceTimer(room, seat, onExpire){
    clearSeatGraceTimer(room, seat);
    room.graceTimers[seat] = setTimeout(() => {
      room.graceTimers[seat] = null;
      if (room.seats[seat]) return; // уже успел переподключиться
      room.tokens[seat] = null;
      onExpire();
    }, reconnectGraceMs);
    if (typeof room.graceTimers[seat].unref === 'function') room.graceTimers[seat].unref();
  }

  function clearSeatGraceTimer(room, seat){
    if (room.graceTimers[seat]){ clearTimeout(room.graceTimers[seat]); room.graceTimers[seat] = null; }
  }

  return {
    rooms, createRoom, getRoom, freeSeat,
    armEmptyTimer, disarmEmptyTimer,
    armSeatGraceTimer, clearSeatGraceTimer,
    reconnectGraceMs
  };
}

function send(ws, msg){
  if (ws && ws.readyState === ws.OPEN) ws.send(JSON.stringify(msg));
}

// Рассылка обоим местам за столом И всем зрителям (шаг 10) — зрителям
// уходят те же сообщения о состоянии партии, что и игрокам, кроме тех,
// что относятся конкретно к месту (это фильтруется на уровне вызывающего
// кода: приватные per-seat сообщения вроде rematch-started шлются отдельно).
function broadcastRoom(room, msg){
  send(room.seats[1], msg);
  send(room.seats[2], msg);
  broadcastSpectators(room, msg);
}

function broadcastSpectators(room, msg){
  for (const specWs of room.spectators) send(specWs, msg);
}

function stateMessage(room, extra){
  return Object.assign({ type: 'state', snapshot: room.match.getSnapshot(), playerNames: room.playerNames }, extra || {});
}

// Статус комнаты для списка в лобби: 'waiting' — ждёт второго игрока (можно
// присоединиться по коду), 'playing' — партия идёт (можно только смотреть),
// null — комната не годится для списка (партия окончена, комната с ботом).
function roomListStatus(room){
  if (room.vsBot || !room.isPublic) return null;
  const snap = room.match.getSnapshot();
  if (snap.gameOver) return null;
  if (!room.seats[1] || !room.seats[2]) return 'waiting';
  return 'playing';
}

function roomListEntry(room){
  const status = roomListStatus(room);
  if (!status) return null;
  return {
    code: room.code,
    sizeKey: room.match.sizeKey,
    targetScore: room.options.targetScore || 0,
    targetFillPercent: typeof room.options.targetFillPercent === 'number' ? room.options.targetFillPercent : 100,
    extraTurnOnCapture: room.options.extraTurnOnCapture === true,
    undoAllowed: room.options.undoAllowed !== false,
    status,
    playerNames: room.playerNames,
    spectatorCount: room.spectators.size
  };
}

// Раздача статики из /public — чтобы тестовый клиент открывался прямо с
// этого же сервера. На проде статику обычно отдают иначе (CDN, отдельный
// хостинг) — здесь это только для удобства локальной проверки.
function serveStatic(req, res){
  const publicDir = path.join(__dirname, 'public');
  let reqPath = decodeURIComponent(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/client.html';
  const filePath = path.join(publicDir, reqPath);
  if (!filePath.startsWith(publicDir)){
    res.writeHead(403); res.end('Forbidden'); return;
  }
  fs.readFile(filePath, (err, data) => {
    if (err){ res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(filePath);
    const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// Возвращает true, если запрос был обработан как /api/* маршрут (в этом
// случае вызывающий код ничего больше с res делать не должен), иначе false —
// тогда запрос отдаётся дальше на serveStatic.
async function handleApiRequest(req, res, auth, gameLog, admin){
  const urlObj = new URL(req.url, 'http://internal');
  const urlPath = urlObj.pathname;
  if (!urlPath.startsWith('/api/')) return false;

  const cors = () => {
    // Тестовый прототип открыт для запросов с любого источника (например,
    // клиент, отданный со статического хостинга отдельно от API) — на
    // проде это стоит сузить до конкретного домена клиента.
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  };
  cors();
  if (req.method === 'OPTIONS'){ res.writeHead(204); res.end(); return true; }

  if (urlPath === '/api/register' && req.method === 'POST'){
    try {
      const body = await readJsonBody(req);
      const result = auth.register(body);
      if (!result.ok) sendJson(res, 409, { error: result.reason, field: result.field });
      else sendJson(res, 201, { user: result.user, token: result.token });
    } catch (err){
      sendJson(res, err.statusCode || 400, { error: err.message || 'bad-request' });
    }
    return true;
  }

  if (urlPath === '/api/login' && req.method === 'POST'){
    try {
      const body = await readJsonBody(req);
      const result = auth.login(body);
      if (!result.ok) sendJson(res, 401, { error: result.reason });
      else sendJson(res, 200, { user: result.user, token: result.token });
    } catch (err){
      sendJson(res, err.statusCode || 400, { error: err.message || 'bad-request' });
    }
    return true;
  }

  if (urlPath === '/api/logout' && req.method === 'POST'){
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    auth.logout(token);
    sendJson(res, 200, { ok: true });
    return true;
  }

  if (urlPath === '/api/me' && req.method === 'GET'){
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const user = auth.verifySession(token);
    if (!user) sendJson(res, 401, { error: 'invalid-session' });
    else sendJson(res, 200, { user });
    return true;
  }

  // Шаг 9: статистика и логи партий (см. gamelog.js). Ничего из этого не
  // требует входа, КРОМЕ /api/stats/me и /api/stats/me/games — там "me"
  // означает "текущий вошедший пользователь", это уже не публичная выдача.
  if (urlPath === '/api/stats/me' && req.method === 'GET'){
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const user = auth.verifySession(token);
    if (!user) sendJson(res, 401, { error: 'invalid-session' });
    else sendJson(res, 200, { nickname: user.nickname, stats: gameLog.getStats(user.id) });
    return true;
  }

  if (urlPath === '/api/stats/me/games' && req.method === 'GET'){
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const user = auth.verifySession(token);
    if (!user) return sendJson(res, 401, { error: 'invalid-session' }), true;
    const limit = parseInt(urlObj.searchParams.get('limit'), 10);
    sendJson(res, 200, { games: gameLog.getRecentGames(user.id, Number.isFinite(limit) ? limit : 20) });
    return true;
  }

  if (urlPath.startsWith('/api/stats/') && req.method === 'GET'){
    // Публичная статистика по нику — например, посмотреть, как играет
    // оппонент. Отдаёт только id/ник + агрегаты, без почты.
    const nickname = decodeURIComponent(urlPath.slice('/api/stats/'.length));
    const user = auth.findPublicUserByNickname(nickname);
    if (!user) sendJson(res, 404, { error: 'user-not-found' });
    else sendJson(res, 200, { nickname: user.nickname, stats: gameLog.getStats(user.id) });
    return true;
  }

  if (urlPath.startsWith('/api/games/') && req.method === 'GET'){
    // Полный лог партии по коду комнаты: сводка + все ходы по порядку.
    // Код комнаты и так уже был известен обоим игрокам (это не секрет
    // сложнее самого приглашения в партию), поэтому эндпоинт открытый.
    const code = decodeURIComponent(urlPath.slice('/api/games/'.length));
    const found = gameLog.getGameByRoomCode(code);
    if (!found) sendJson(res, 404, { error: 'game-not-found' });
    else sendJson(res, 200, found);
    return true;
  }

  // Шаг 11: "сколько партий в базе" и "виден ли прогресс дообучения бота".
  // Открытые GET-эндпоинты, как и /api/games/:code выше, — это read-only
  // сводка без личных данных (email/пароли не выдаются), просто счётчики
  // и веса бота. Для боевого продакшена эти два эндпоинта стоит закрыть
  // отдельной админской авторизацией — здесь её сознательно нет, как и в
  // остальном прототипе (см. README, «Что дальше»).
  if (urlPath === '/api/admin/summary' && req.method === 'GET'){
    sendJson(res, 200, gameLog.getDbSummary());
    return true;
  }

  if (urlPath.startsWith('/api/bot/weights/') && req.method === 'GET'){
    const difficulty = decodeURIComponent(urlPath.slice('/api/bot/weights/'.length));
    if (!Engine.DIFFICULTY[difficulty]) return sendJson(res, 404, { error: 'unknown-difficulty' }), true;
    const limit = parseInt(urlObj.searchParams.get('limit'), 10);
    sendJson(res, 200, {
      difficulty,
      current: gameLog.getCurrentBotWeights(difficulty) || { ...Engine.BOT_WEIGHTS, meta: { source: 'default (никогда не дообучался)' } },
      history: gameLog.getBotWeightsHistory(difficulty, Number.isFinite(limit) ? limit : 50)
    });
    return true;
  }

  // Шаг 12: запуск/статус дообучения бота — см. createTrainingRunner()
  // выше про то, почему это отдельный процесс, а не код в этом файле.
  // Единая проверка авторизации на оба эндпоинта: без ADMIN_TOKEN в
  // окружении сервера — 503 (осознанно выключено), с ним — нужен тот же
  // секрет в заголовке X-Admin-Token.
  if (urlPath === '/api/admin/train' && (req.method === 'POST' || req.method === 'GET')){
    if (!admin.training.isEnabled()) return sendJson(res, 503, { error: 'admin-training-disabled', reason: 'ADMIN_TOKEN не задан в окружении сервера' }), true;
    if (!safeEqualStrings(req.headers['x-admin-token'], admin.adminToken)) return sendJson(res, 403, { error: 'forbidden' }), true;
    if (req.method === 'GET') return sendJson(res, 200, admin.training.publicState()), true;
    let body = {};
    try { body = await readJsonBody(req); } catch (err){ body = {}; } // тело необязательно — без него берутся дефолты train-bot.js
    const result = admin.training.start(body);
    if (!result.ok){
      const status = result.reason === 'already-running' ? 409 : 400;
      return sendJson(res, status, { error: result.reason, run: admin.training.publicState() }), true;
    }
    sendJson(res, 202, { started: true, run: admin.training.publicState() });
    return true;
  }

  // Пилот actor-learner (внешний оптимизатор, например Colab, присылает
  // веса-кандидата — сервер СИНХРОННО прогоняет self-play и сразу отдаёт
  // результат, ничего не сохраняя в bot_weights). В отличие от
  // /api/admin/train это НЕ спавнит дочерний процесс: расчёт блокирует
  // event loop на время запроса. Это осознанно приемлемо только на
  // выделенном под обучение инстансе без живых игроков — см. обсуждение
  // в переписке. На проде с реальными игроками эта ручка не должна
  // вызываться параллельно с их ходами.
  if (urlPath === '/api/admin/selfplay-eval' && req.method === 'POST'){
    if (!admin.training.isEnabled()) return sendJson(res, 503, { error: 'admin-training-disabled', reason: 'ADMIN_TOKEN не задан в окружении сервера' }), true;
    if (!safeEqualStrings(req.headers['x-admin-token'], admin.adminToken)) return sendJson(res, 403, { error: 'forbidden' }), true;
    let body;
    try { body = await readJsonBody(req); } catch (err){ return sendJson(res, 400, { error: 'invalid-json-body' }), true; }

    const candidateWeights = body && body.candidateWeights;
    if (!candidateWeights || typeof candidateWeights !== 'object'){
      return sendJson(res, 400, { error: 'candidateWeights-required' }), true;
    }
    const sizeKey = (typeof body.sizeKey === 'string' && Engine.SIZES[body.sizeKey]) ? body.sizeKey : 'medium';
    const games = Math.max(1, Math.min(200, parseInt(body.games, 10) || 20));
    const seed = Number.isFinite(parseInt(body.seed, 10)) ? (parseInt(body.seed, 10) >>> 0) : (Date.now() >>> 0);
    const fillPercent = (body.fillPercent === undefined || body.fillPercent === null)
      ? undefined
      : Math.max(1, Math.min(100, parseInt(body.fillPercent, 10) || 60));
    const difficulty = (typeof body.difficulty === 'string' && Engine.DIFFICULTY[body.difficulty]) ? body.difficulty : 'strong';

    const incumbentWeights = (body.incumbentWeights && typeof body.incumbentWeights === 'object')
      ? body.incumbentWeights
      : (gameLog.getCurrentBotWeights(difficulty) || { ...Engine.BOT_WEIGHTS });

    const startedAt = Date.now();
    const openings = TrainBot.loadOpenings(gameLog, sizeKey, 6);
    const rng = TrainBot.makeRng(seed);
    const result = TrainBot.contest(sizeKey, openings, incumbentWeights, candidateWeights, games, rng, fillPercent);
    const elapsedMs = Date.now() - startedAt;

    sendJson(res, 200, {
      ...result, elapsedMs, gamesPlayed: games, openingsUsed: openings.length,
      sizeKey, fillPercent: fillPercent ?? null, seed
    });
    return true;
  }

  // Ручное сохранение готовых весов (например, финальный результат пилота
  // с Colab) — в отличие от /api/admin/train ничего не считает сама, только
  // валидирует и пишет новую строку в bot_weights (та же таблица/история,
  // что и у tools/train-bot.js). source в БД будет 'external' — по нему
  // в GET /api/bot/weights/:difficulty видно, что это не local self-play.
  if (urlPath === '/api/admin/bot-weights' && req.method === 'POST'){
    if (!admin.training.isEnabled()) return sendJson(res, 503, { error: 'admin-training-disabled', reason: 'ADMIN_TOKEN не задан в окружении сервера' }), true;
    if (!safeEqualStrings(req.headers['x-admin-token'], admin.adminToken)) return sendJson(res, 403, { error: 'forbidden' }), true;
    let body;
    try { body = await readJsonBody(req); } catch (err){ return sendJson(res, 400, { error: 'invalid-json-body' }), true; }

    const difficulty = (typeof body.difficulty === 'string' && Engine.DIFFICULTY[body.difficulty]) ? body.difficulty : null;
    if (!difficulty) return sendJson(res, 400, { error: 'unknown-difficulty' }), true;
    const w = body.weights;
    if (!w || !TrainBot.WEIGHT_KEYS.every(k => typeof w[k] === 'number' && Number.isFinite(w[k]))){
      return sendJson(res, 400, { error: 'weights-must-include', keys: TrainBot.WEIGHT_KEYS }), true;
    }

    // B05 (issue #28): внешние веса публикуются по тому же заранее выбранному
    // критерию, что и tools/publish-weights.js: нужен test-отчёт benchmark
    // (body.report) для этих же весов с нижней границей 95% CI > 0.5 и без
    // ошибок корректности. Иначе запись в bot_weights обходила бы проверку.
    const PublishWeights = require('./tools/publish-weights.js');
    const candidate = { format: 'tochki-weights-candidate', version: 1, difficulty, weights: w,
      bundle: { engineVersion: Engine.ENGINE_VERSION, botVersion: Engine.BOT_VERSION, source: 'external' } };
    const chk = PublishWeights.checkReport(body.report, candidate);
    if (!chk.ok) return sendJson(res, 422, { error: 'publication-criterion-not-met', criterion: PublishWeights.CRITERION, reasons: chk.reasons }), true;
    const cur = gameLog.getCurrentBotWeights(difficulty);
    const previous = cur
      ? { id: null, weights: { potential: cur.potential, cohesion: cur.cohesion, stones: cur.stones, liberty: cur.liberty }, source: cur.meta && cur.meta.source }
      : { id: null, weights: { ...Engine.BOT_WEIGHTS }, source: 'engine-default' };
    gameLog.saveBotWeights(difficulty, w, {
      source: 'external',
      winRate: body.report.vsBaseline.score,
      gamesPlayed: body.report.vsBaseline.pairs * 2,
      note: JSON.stringify({ format: 'tochki-weights-publication', version: 1, action: 'publish', criterion: PublishWeights.CRITERION,
        bundle: candidate.bundle, test: { corpus: body.report.corpus, vsBaseline: body.report.vsBaseline }, previous,
        comment: typeof body.note === 'string' ? body.note.slice(0, 500) : undefined })
    });
    sendJson(res, 201, { saved: true, difficulty, weights: w });
    return true;
  }

  sendJson(res, 404, { error: 'not-found' });
  return true;
}

// Простое сравнение строк без утечки через тайминг — тем же приёмом, что
// verifyPassword() в auth.js, но без соли/хэширования: ADMIN_TOKEN — это
// один статический секрет из окружения, а не пароль пользователя.
function safeEqualStrings(a, b){
  const bufA = Buffer.from(String(a == null ? '' : a));
  const bufB = Buffer.from(String(b == null ? '' : b));
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

// Шаг 12 — POST /api/admin/train (запуск дообучения бота, вариант «В» из
// обсуждения): эндпоинт только СПАВНИТ tools/train-bot.js ОТДЕЛЬНЫМ
// процессом (child_process.spawn) и сразу отвечает — сам self-play
// (синхронный alphaBeta-перебор) НИКОГДА не считается внутри процесса
// сервера, иначе на всё время обучения зависли бы ходы живых игроков (та
// же причина, по которой ход самого бота стоило бы в будущем вынести в
// worker_threads — см. README). Дочерний процесс независим: упадёт или
// зависнет — на текущие партии это не повлияет.
//
// Защита: включается только если задан ADMIN_TOKEN (переменная окружения
// или serverOptions.adminToken) — без него эндпоинт всегда отвечает 503, а
// не молча остаётся открытым. Запрос должен нести тот же секрет в
// заголовке X-Admin-Token. Без этого кто угодно смог бы бесплатно грузить
// CPU сервера повторными запусками self-play.
function createTrainingRunner({ dbPath, adminToken }){
  const state = { running: false, pid: null, params: null, startedAt: null, finishedAt: null, exitCode: null, signal: null, ok: null, output: [] };
  let activeChild = null;
  let completion = Promise.resolve();
  let stopping = null;

  // Await close (including stdio), not merely kill(): only then is it safe
  // to remove the database directory. Escalate if SIGTERM is ignored.
  function stop(){
    if (!activeChild) return completion;
    if (stopping) return stopping;
    const child = activeChild;
    child.kill('SIGTERM');
    const timer = setTimeout(() => child.kill('SIGKILL'), 1000);
    stopping = completion.finally(() => clearTimeout(timer));
    return stopping;
  }

  function pushLine(line){
    state.output.push(line);
    // Держим только хвост лога — это статус для человека в браузере/curl,
    // не полноценное хранилище логов; полная история решений бота и так
    // остаётся в bot_weights.note (см. GET /api/bot/weights/:difficulty).
    if (state.output.length > 200) state.output.shift();
  }

  function sanitizeParams(raw){
    raw = raw || {};
    const clampInt = (v, lo, hi, def) => {
      const n = parseInt(v, 10);
      return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : def;
    };
    return {
      difficulty: (typeof raw.difficulty === 'string' && Engine.DIFFICULTY[raw.difficulty]) ? raw.difficulty : 'strong',
      // Верхние границы — не про качество обучения, а чтобы один вызов
      // эндпоинта не мог случайно/намеренно запустить многочасовой прогон.
      generations: clampInt(raw.generations, 1, 50, 4),
      population: clampInt(raw.population, 1, 20, 4),
      games: clampInt(raw.games, 1, 100, 8),
      sizeKey: (typeof raw.sizeKey === 'string' && Engine.SIZES[raw.sizeKey]) ? raw.sizeKey : 'medium',
      seed: Number.isFinite(parseInt(raw.seed, 10)) ? (parseInt(raw.seed, 10) >>> 0) : (Date.now() >>> 0),
      // необязательный override условия окончания self-play партий (см.
      // --fill-percent в tools/train-bot.js); undefined = поведение по
      // умолчанию (дебют реальной партии либо 35%).
      fillPercent: (raw.fillPercent === undefined || raw.fillPercent === null)
        ? undefined
        : clampInt(raw.fillPercent, 1, 100, undefined)
    };
  }

  function start(rawParams){
    if (state.running) return { ok: false, reason: 'already-running' };
    if (dbPath === ':memory:'){
      // Дочерний процесс откроет СВОЙ ':memory:' — отдельная, никак не
      // связанная с работающим сервером база; результат обучения просто
      // потеряется. В реальном деплое это не встречается (см. db.js) —
      // это защита конкретно от такого несовпадения.
      return { ok: false, reason: 'in-memory-db' };
    }
    const params = sanitizeParams(rawParams);
    const args = [
      path.join(__dirname, 'tools', 'train-bot.js'),
      '--difficulty', params.difficulty,
      '--generations', String(params.generations),
      '--population', String(params.population),
      '--games', String(params.games),
      '--size', params.sizeKey,
      '--seed', String(params.seed),
      '--db', dbPath,
      // B05 (issue #28): обучение больше не публикует веса в bot_weights —
      // пишет файл-кандидат рядом с БД; публикация только через
      // tools/publish-weights.js по test-benchmark (docs/B05_WEIGHTS.md).
      '--out', path.join(path.dirname(dbPath), `weights-candidate-${params.difficulty}-${params.seed}.json`)
    ];
    if (params.fillPercent !== undefined) args.push('--fill-percent', String(params.fillPercent));
    const child = spawn(process.execPath, args, { cwd: __dirname });
    activeChild = child;
    stopping = null;
    state.running = true;
    state.pid = child.pid;
    state.params = params;
    state.startedAt = Date.now();
    state.finishedAt = null;
    state.exitCode = null;
    state.signal = null;
    state.ok = null;
    state.output = [];
    child.stdout.on('data', (chunk) => { for (const line of chunk.toString().split('\n')) if (line) pushLine(line); });
    child.stderr.on('data', (chunk) => { for (const line of chunk.toString().split('\n')) if (line) pushLine('[stderr] ' + line); });
    completion = new Promise((resolve) => {
      child.once('close', (code, signal) => {
        activeChild = null;
        state.running = false;
        state.finishedAt = Date.now();
        state.exitCode = code;
        state.signal = signal;
        state.ok = code === 0 && !signal;
        resolve();
      });
    });
    child.on('error', (err) => {
      // Node emits close after error too; keep the runner busy until then.
      state.ok = false;
      pushLine('[spawn-error] ' + err.message);
    });
    return { ok: true, params, pid: child.pid };
  }

  function publicState(){
    // outputTail, а не весь output — GET-ответ не должен незаметно
    // разрастись до сотен строк лога на каждый опрос статуса.
    const { output, ...rest } = state;
    return { ...rest, outputTail: output.slice(-30) };
  }

  return { start, stop, publicState, isEnabled: () => !!adminToken };
}

function sanitizeCreateOptions(raw){
  raw = raw || {};
  const options = {};
  if (typeof raw.sizeKey === 'string' && Engine.SIZES[raw.sizeKey]) options.sizeKey = raw.sizeKey;
  if (Number.isFinite(raw.targetScore)) options.targetScore = raw.targetScore;
  if (Number.isFinite(raw.targetFillPercent)) options.targetFillPercent = raw.targetFillPercent;
  // extraTurnOnCapture — доп. ход за окружение (шаг 13); решает создатель
  // комнаты, применяется прямо в Engine.createMatch (см. gameEngine.js).
  if (raw.extraTurnOnCapture === true) options.extraTurnOnCapture = true;
  // firstMove — кто ставит первую точку партии: 'creator' (по умолчанию,
  // как и раньше) или 'opponent' (второй игрок/бот). В серверной модели
  // место 1 всегда закреплено за создателем комнаты (см. create-room
  // ниже), поэтому выбор однозначно переводится в firstPlayer: 1|2 для
  // движка. Не имеет смысла для матчмейкинга (find-match) — там нет
  // понятия "создатель", поэтому normalizeMatchOptions это поле не читает.
  if (raw.firstMove === 'opponent') options.firstPlayer = 2;
  else if (raw.firstMove === 'creator') options.firstPlayer = 1;
  // undoAllowed — разрешена ли отмена хода в этой партии; решает создатель
  // комнаты (шаг 15). По умолчанию true (прежнее поведение — отмена всегда
  // доступна), поэтому передаём в Engine.createMatch только явное false.
  // Дальше вся логика — в gameEngine.js (canUndoLastMove/undoLastMove).
  if (raw.undoAllowed === false) options.undoAllowed = false;
  // startPosition — стартовая позиция партии (issue #47): 'empty' (по
  // умолчанию, пустое поле) или 'cross' (4 точки крестом в центре поля).
  // Передаём в Engine.createMatch только явное 'cross'.
  if (raw.startPosition === 'cross') options.startPosition = 'cross';
  return options;
}

// vsBot/botDifficulty — это метаданные КОМНАТЫ, а не движка партии
// (Engine.createMatch про бота ничего не знает — он только считает ход
// по запросу через match.botMove()). Поэтому разбираем их отдельно от
// sanitizeCreateOptions, который формирует опции именно для createMatch().
function sanitizeRoomOptions(raw){
  raw = raw || {};
  const matchOptions = sanitizeCreateOptions(raw);
  const vsBot = raw.vsBot === true;
  const botDifficulty = (typeof raw.botDifficulty === 'string' && Engine.DIFFICULTY[raw.botDifficulty])
    ? raw.botDifficulty
    : 'normal';
  // Комната с ботом никогда не публикуется в лобби — это защищённый
  // одиночный сценарий, смотреть там особо не на что, а претендовать на
  // место 2 всё равно нельзя (см. freeSeat).
  const isPublic = !vsBot && raw.isPublic === true;
  // S7 (#61): арбитр бота за флагом monitor (по умолчанию false) и верхний
  // предел времени хода при тревоге (секунды, настраивается в интерфейсе,
  // потому что время зависит от устройства). Ограничен 1–60 с.
  const botMonitor = vsBot && raw.botMonitor === true;
  const lim = Number(raw.botAlarmLimitSec);
  const botAlarmLimitSec = Number.isFinite(lim) ? Math.max(1, Math.min(60, Math.floor(lim))) : 20;
  return { matchOptions, vsBot, botDifficulty, isPublic, botMonitor, botAlarmLimitSec };
}

// Матчмейкинг сводит только игроков с ОДИНАКОВЫМИ настройками партии —
// иначе пришлось бы выбирать, чьи правила побеждают, что нечестно и неявно
// для игрока. Поэтому опции сначала приводятся к полному, однозначному
// виду (без "не указано"), а очередь ожидания разбита по ключу этих опций:
// одинаковые настройки -> одна и та же очередь -> первая же пара сводится.
function normalizeMatchOptions(raw){
  const o = sanitizeCreateOptions(raw);
  return {
    sizeKey: o.sizeKey || 'medium',
    targetScore: Number.isFinite(o.targetScore) ? Math.max(0, Math.min(9999, Math.floor(o.targetScore))) : 0,
    targetFillPercent: Number.isFinite(o.targetFillPercent) ? Math.max(0, Math.min(100, Math.floor(o.targetFillPercent))) : 100
  };
}
function matchOptionsKey(o){
  return `${o.sizeKey}|${o.targetScore}|${o.targetFillPercent}`;
}

function createServer(serverOptions){
  serverOptions = serverOptions || {};
  const reconnectGraceMs = serverOptions.reconnectGraceMs || DEFAULT_RECONNECT_GRACE_MS;
  const emptyRoomTtlMs = serverOptions.emptyRoomTtlMs || DEFAULT_EMPTY_ROOM_TTL_MS;

  // dbPath: ':memory:' удобно для тестов (см. test/e2e.js) — не оставляет
  // файлов на диске и каждый прогон теста начинает с чистой базы.
  const dbPath = resolveDbPath(serverOptions.dbPath);
  const db = serverOptions.db || openDatabase(dbPath);
  const auth = createAuth(db);
  const gameLog = createGameLog(db);

  // ADMIN_TOKEN пуст по умолчанию — это осознанно ВЫКЛЮЧАЕТ
  // /api/admin/train, а не оставляет его открытым (см. createTrainingRunner
  // выше). Чтобы включить: ADMIN_TOKEN=... в окружении сервера (или
  // serverOptions.adminToken при создании сервера тестами/встраиванием).
  const ADMIN_TOKEN = serverOptions.adminToken !== undefined ? serverOptions.adminToken : (process.env.ADMIN_TOKEN || '');
  const training = createTrainingRunner({ dbPath, adminToken: ADMIN_TOKEN });
  const adminCtx = { training, adminToken: ADMIN_TOKEN };

  const {
    rooms, createRoom, getRoom, freeSeat,
    armEmptyTimer, disarmEmptyTimer,
    armSeatGraceTimer, clearSeatGraceTimer
  } = createRoomsRegistry({
    reconnectGraceMs, emptyRoomTtlMs,
    onRoomExpired: (room) => {
      // A10: комната удаляется — идущий поиск бота снимаем, его ответ
      // всё равно отбросит botTicketValid (getRoom(code) !== room).
      cancelBotSearch(room);
      gameLog.abandonIfUnfinished(room);
      // Зрители (шаг 10) не держат место и не участвуют в reconnect —
      // им нужно явное уведомление, что комната пропала из памяти сервера.
      broadcastSpectators(room, { type:'room-closed', code: room.code });
    }
  });

  // Веса оценочной функции бота — если tools/train-bot.js уже что-то
  // подобрал для этой сложности, берём последнее "поколение" из БД, иначе
  // — встроенные в движок значения по умолчанию. Чтение из bot_weights —
  // это простой индексированный SELECT в SQLite (синхронный, доли мс), так
  // что дёшево делать его при каждом ходе бота, а не только при старте
  // сервера: новое поколение весов от train-bot.js подхватывается сразу,
  // без перезапуска процесса.
  function botWeightsFor(difficulty){
    const trained = gameLog.getCurrentBotWeights(difficulty || 'normal');
    if (trained) return trained;
    return Engine.BOT_WEIGHTS;
  }

  // A10 (issue #15): поиск хода бота вынесен в ограниченный пул
  // worker_threads (botPool.js -> botWorker.js -> gameEngine.searchMove),
  // чтобы strong (~2000 мс) не блокировал event loop всех комнат.
  // Предел параллелизма/очередь/таймаут — serverOptions.botPool или env
  // BOT_POOL_SIZE / BOT_QUEUE / BOT_TIMEOUT_MS. BOT_POOL_SIZE=0 (или
  // botPool:{size:0}) — прежний синхронный режим (нужен для замера "до").
  const botPoolCfg = Object.assign({
    size: process.env.BOT_POOL_SIZE !== undefined ? Number(process.env.BOT_POOL_SIZE) : 2,
    maxQueue: process.env.BOT_QUEUE !== undefined ? Number(process.env.BOT_QUEUE) : 16,
    timeoutMs: process.env.BOT_TIMEOUT_MS !== undefined ? Number(process.env.BOT_TIMEOUT_MS) : 10000
  }, serverOptions.botPool || {});
  const { createBotPool } = require('./botPool.js');
  const botPool = Number(botPoolCfg.size) > 0 ? createBotPool(botPoolCfg) : null;
  // Сколько раз повторять поиск при queue-full/timeout/worker-crashed,
  // прежде чем сходить синхронно с минимальным бюджетом (партия не должна
  // зависнуть навсегда из-за сбоя потока).
  const BOT_RETRY_LIMIT = 2;
  const BOT_RETRY_DELAY_MS = 250;
  const BOT_FALLBACK_OPTS = { nodeLimit: 1500, timeLimit: 150 };

  const httpServer = http.createServer((req, res) => {
    handleApiRequest(req, res, auth, gameLog, adminCtx).then((handled) => {
      if (!handled) serveStatic(req, res);
    }).catch((err) => {
      console.error('API error:', err);
      if (!res.headersSent) sendJson(res, 500, { error: 'internal-error' });
    });
  });
  const wss = new WebSocketServer({ server: httpServer });

  // Очередь ожидания матчмейкинга: Map<optionsKey, ws[]>. Комнаты по коду
  // (шаг 3) и матчмейкинг (шаг 4) используют один и тот же createRoom() —
  // разница только в том, кто сводит игроков: сам человек (делится кодом)
  // или сервер (как только в очереди набралась пара с одинаковыми опциями).
  const matchmakingQueues = new Map();

  function removeFromQueue(ws){
    if (!ws.searching || !ws.searchKey) return;
    const queue = matchmakingQueues.get(ws.searchKey);
    if (queue){
      const idx = queue.indexOf(ws);
      if (idx !== -1) queue.splice(idx, 1);
      if (!queue.length) matchmakingQueues.delete(ws.searchKey);
    }
    ws.searching = false;
    ws.searchKey = null;
  }

  function seatWithToken(room, seat, ws, player){
    room.seats[seat] = ws;
    room.tokens[seat] = generateToken();
    room.playerNames[seat] = (player && player.nickname) || null;
    room.playerUserIds[seat] = (player && player.id) || null;
    ws.roomCode = room.code;
    ws.seat = seat;
    return room.tokens[seat];
  }

  // authToken — токен сессии из учётной записи (не путать с токеном
  // переподключения к месту в комнате, который сервер сам выдаёт в
  // room-created/room-joined и т.д.). Если он не передан, невалиден или
  // истёк — это не ошибка: игрок просто остаётся гостем без ника и без
  // привязки статистики к учётной записи.
  function resolvePlayer(authToken){
    if (!authToken) return null;
    return auth.verifySession(authToken); // {id, nickname, email} | null
  }

  // Небольшая задержка перед запуском поиска хода бота — чтобы ответ на ход
  // человека успел уйти раньше. Сам поиск (A10, issue #15) идёт в пуле
  // worker_threads (botPool.js) и event loop не блокирует; синхронный
  // режим остался только при BOT_POOL_SIZE=0 и как запасной малый поиск
  // после сбоев потока (см. runBotSearch и docs/A10_LOAD.md).
  const BOT_MOVE_DELAY_MS = 30;

  // Общая точка записи хода в лог для человека и для бота — оба пути
  // ведут через applyMove() и должны одинаково попадать в moves/games,
  // поэтому вынесено отдельно, а не продублировано в двух местах.
  function recordMoveInLog(room, seat, x, y, result){
    const moveIndex = room.moveCount;
    room.moveCount += 1;
gameLog.recordTransition(room, moveIndex, seat, x, y, result);
  }

  // Применяет уже одобренную отмену последнего хода (согласием живого
  // соперника или авто-согласием бота — см. вызовы ниже) и рассылает
  // новое состояние. moveCount НЕ уменьшаем: это счётчик строк в
  // персистентном логе БД (gamelog), а не число точек на доске — лог
  // остаётся честной историей партии, включая отменённый ход (см. шапку
  // файла). Живая доска в памяти при этом полностью откатывается.
  function applyApprovedUndo(room){
    // A10: поиск бота, начатый до отмены, считал уже несуществующую
    // позицию — снимаем его (и в любом случае его результат отбросит
    // botTicketValid по revision/match).
    cancelBotSearch(room);
    const result = room.match.undoLastMove();
    room.pendingUndo = null;
    if (!result.ok){ maybeTriggerBotMove(room); return result; }
    gameLog.saveReplay(room);
    broadcastRoom(room, stateMessage(room, { note: 'undo-applied' }));
    // Если после отмены снова наступила очередь бота (например, отменили
    // ход человека, который шёл после хода бота, и до отмены ход опять
    // был передан человеку) — пусть бот походит сам, как обычно.
    maybeTriggerBotMove(room);
    return result;
  }

  // A10: "билет" поиска бота — room.botTicket. Один активный поиск на
  // комнату; результат применяется, только если билет всё ещё текущий,
  // комната та же (не удалена), партия та же (room.match — не реванш),
  // revision (длина moveLog) не изменилась, партия не окончена и ход
  // фактически за ботом (учитывает extraTurnOnCapture).
  let botTicketSeq = 0;

  function cancelBotSearch(room){
    const t = room.botTicket;
    if (!t) return;
    room.botTicket = null;
    if (botPool) botPool.cancel(t.key);
  }

  function botTicketValid(room, t){
    if (getRoom(room.code) !== room || room.botTicket !== t || room.match !== t.match ||
        room.gameId !== t.gameId || room.match.getMoveLog().length !== t.revision){
      if (room.botTicket === t) room.botTicket = null;
      return false;
    }
    const snap = room.match.getSnapshot();
    if (snap.gameOver || snap.current !== room.botSeat){
      room.botTicket = null;
      return false;
    }
    return true;
  }

  function maybeTriggerBotMove(room){
    if (!room.vsBot) return;
    const snap = room.match.getSnapshot();
    if (snap.gameOver || snap.current !== room.botSeat) return;
    if (room.botTicket) return; // поиск для этой позиции уже идёт — не дублируем
    const t = { id: ++botTicketSeq, key: `${room.code}#${botTicketSeq}`, match: room.match,
      gameId: room.gameId, revision: room.match.getMoveLog().length, attempts: 0 };
    room.botTicket = t;
    setTimeout(() => runBotSearch(room, t), BOT_MOVE_DELAY_MS);
  }

  function runBotSearch(room, t){
    if (!botTicketValid(room, t)) return;
    const difficulty = room.botDifficulty;
    const weights = botWeightsFor(difficulty);
    if (!botPool){
      // Синхронный режим (BOT_POOL_SIZE=0) — прежнее поведение, для замера "до".
      return applyBotResult(room, t, room.match.botMove(difficulty, weights), weights);
    }
    // A10: после BOT_RETRY_LIMIT неудач (queue-full/timeout/worker-crashed)
    // НЕ уходим в синхронный поиск на основном event loop — повторяем в том
    // же пуле, но с малым бюджетом (BOT_FALLBACK_OPTS) и растущей задержкой.
    // Пул пересоздаёт упавшие/зависшие потоки, так что партия не зависает,
    // а другие комнаты не получают блокировку event loop.
    const degraded = t.attempts > BOT_RETRY_LIMIT;
    const msg = { snapshot: room.match.getSnapshot(), difficulty, weights,
      gameId: t.gameId, revision: t.revision };
        if (degraded) msg.searchOpts = BOT_FALLBACK_OPTS;
    else if (room.botMonitor){
      // S7 (#61): арбитр включён для комнаты. Верхний предел локального поиска
      // при тревоге — из настроек интерфейса (секунды -> мс).
      const capMs = (room.botAlarmLimitSec || 20) * 1000;
      msg.searchOpts = { monitor: true, maxAlarmTimeLimit: capMs, alarmTimeLimit: Math.min(10000, capMs) };
    }
        // S7 (#61): при включённом мониторе жёсткий таймаут запроса расширяется на
    // верхний предел тревоги из настроек комнаты: общий поиск (таймаут пула) +
    // локальный поиск решателя (до botAlarmLimitSec). Иначе пул убил бы поток
    // на BOT_TIMEOUT_MS (10 с), и предел 10–20 с из интерфейса не работал бы.
    const searchMeta = { key: t.key };
    if (!degraded && room.botMonitor){
      searchMeta.timeoutMs = botPool.timeoutMs + (room.botAlarmLimitSec || 20) * 1000;
    }
    botPool.search(msg, searchMeta)
      .then((r) => {
        if (!botTicketValid(room, t)) return; // устаревший ответ — игнорируем
        applyBotResult(room, t, r.move, weights);
      })
      .catch((err) => {
        const code = err && err.code;
        if (code === 'cancelled' || code === 'pool-closed'){
          if (room.botTicket === t) room.botTicket = null;
          return;
        }
        if (!botTicketValid(room, t)) return;
        t.attempts += 1;
        if (t.attempts <= BOT_RETRY_LIMIT + 1){
          // Сначала BOT_RETRY_LIMIT обычных повторов в пуле, затем ещё один
          // повтор в пуле с малым бюджетом (BOT_FALLBACK_OPTS), задержка
          // растёт (250/500/1000 мс). Event loop при этом не блокируется.
          if (t.attempts === BOT_RETRY_LIMIT + 1){
            console.error('bot search failed, retrying in pool with small budget:', code, err && err.message);
          }
          const delay = Math.min(2000, BOT_RETRY_DELAY_MS * Math.pow(2, Math.max(0, t.attempts - 1)));
          const tm = setTimeout(() => runBotSearch(room, t), delay);
          if (typeof tm.unref === 'function') tm.unref();
          return;
        }
        // Пул стабильно не отвечает (все потоки зависают/падают) — чтобы
        // партия не зависла навсегда, последний шанс: малый синхронный поиск
        // с жёстким потолком 1500 узлов / 150 мс. Это ограниченная по времени
        // и редкая (только при аварии пула) блокировка, а не штатный путь.
        console.error('bot search failed in pool, fallback to small sync search:', code, err && err.message);
        const mv = room.match.botMove(difficulty, weights, BOT_FALLBACK_OPTS);
        applyBotResult(room, t, mv, weights);
      });
  }

  function applyBotResult(stillThere, t, move, weights){
    if (stillThere.botTicket === t) stillThere.botTicket = null;
    {
      if (!move) return;
      const result = stillThere.match.applyMove(stillThere.botSeat, move.x, move.y, {
        difficulty: stillThere.botDifficulty,
        botVersion: Engine.BOT_VERSION,
        weightsVersion: weights.meta ? `db-${weights.meta.createdAt}` : Engine.WEIGHTS_VERSION,
        seed: null,
        budgets: { ...Engine.DIFFICULTY[stillThere.botDifficulty] },
        weights: { potential: weights.potential, cohesion: weights.cohesion,
          stones: weights.stones, liberty: weights.liberty }
      });
      if (!result.ok) return; // защитная проверка — по правилам бот всегда должен ходить легально
      recordMoveInLog(stillThere, stillThere.botSeat, move.x, move.y, result);
      broadcastRoom(stillThere, stateMessage(stillThere, { lastMove: { x: move.x, y: move.y, player: stillThere.botSeat }, extraTurn: result.extraTurn }));
      // extraTurnOnCapture: если ход бота сам привёл к захвату, ход
      // остаётся за ботом (current не сменился) — считаем ещё один ход,
      // а не ждём (несуществующего) хода человека.
      maybeTriggerBotMove(stillThere);
    }
  }

  // Шаг 10: реванш в той же комнате — та же комната/код/правила, но новая
  // партия (новая строка в games, room.match и moveCount с нуля). Кто сидит
  // за столом (room.seats/tokens/playerNames) не трогаем — соперник тот же,
  // если он остался; если он ушёл (см. 'leave-room'), место 2 просто пустое
  // и ждёт кого угодно нового по тому же коду.
  function startRematch(room){
    // A10: поиск для прошлой партии больше не нужен; его ответ всё равно
    // отбросит botTicketValid (room.match/gameId сменятся).
    cancelBotSearch(room);
    room.match = Engine.createMatch(room.options);
    room.moveCount = 0;
    room.rematchVotes = new Set();
    room.pendingUndo = null;
    room.gameId = gameLog.startGame(room);
    const snapshot = room.match.getSnapshot();
    [1, 2].forEach((seat) => {
      const seatWs = room.seats[seat];
      if (seatWs) send(seatWs, { type:'rematch-started', seat, token: room.tokens[seat], snapshot, playerNames: room.playerNames, vsBot: room.vsBot });
    });
    broadcastSpectators(room, { type:'state', snapshot, playerNames: room.playerNames, note:'rematch-started' });
    // Как и при create-room: если по правилам комнаты первым ходит бот
    // (firstMove:'opponent'), реванш тоже должен начаться с его хода.
    maybeTriggerBotMove(room);
  }

  wss.on('connection', (ws) => {
    ws.roomCode = null;
    ws.seat = null;
    ws.searching = false;
    ws.searchKey = null;
    ws.spectating = false;

    ws.on('message', (raw) => {
      let msg;
      try { msg = JSON.parse(raw); } catch (e){ return send(ws, { type:'error', reason:'bad-json' }); }

      if (msg.type === 'create-room'){
        if (ws.roomCode) return send(ws, { type:'error', reason:'already-in-room' });
        const { matchOptions, vsBot, botDifficulty, isPublic, botMonitor, botAlarmLimitSec } = sanitizeRoomOptions(msg.options);
        const room = createRoom(matchOptions);
        room.vsBot = vsBot;
        room.botSeat = vsBot ? 2 : null;
        room.botDifficulty = vsBot ? botDifficulty : null;
        room.botMonitor = !!botMonitor;
        room.botAlarmLimitSec = botAlarmLimitSec;
        room.isPublic = isPublic;
        if (vsBot) room.playerNames[2] = botDifficulty === 'strong' ? 'Бот (сильный)' : 'Бот (обычный)';
        const token = seatWithToken(room, 1, ws, resolvePlayer(msg.authToken));
        room.gameId = gameLog.startGame(room);
        send(ws, { type:'room-created', code: room.code, seat: 1, token, snapshot: room.match.getSnapshot(), vsBot, isPublic, playerNames: room.playerNames });
        // firstMove:'opponent' против бота — бот ходит первым сам, без
        // ожидания хода человека (обычно эту роль выполняет вызов после
        // 'move' человека, но здесь человек ещё не ходил вовсе).
        maybeTriggerBotMove(room);
        return;
      }

      if (msg.type === 'join-room'){
        if (ws.roomCode) return send(ws, { type:'error', reason:'already-in-room' });
        const room = getRoom(msg.code);
        if (!room) return send(ws, { type:'error', reason:'room-not-found' });
        const seat = freeSeat(room);
        if (!seat) return send(ws, { type:'error', reason:'room-full' });

        disarmEmptyTimer(room);
        const player = resolvePlayer(msg.authToken);
        const token = seatWithToken(room, seat, ws, player);
        gameLog.recordSecondPlayer(room.gameId, player && player.id, player && player.nickname);
        send(ws, { type:'room-joined', code: room.code, seat, token, snapshot: room.match.getSnapshot(), playerNames: room.playerNames });
        // создателю тоже нужно узнать, что оппонент сел за стол (и как его зовут)
        broadcastRoom(room, stateMessage(room, { note: 'seat-update' }));
        return;
      }

      if (msg.type === 'find-match'){
        if (ws.roomCode) return send(ws, { type:'error', reason:'already-in-room' });
        if (ws.searching) return send(ws, { type:'error', reason:'already-searching' });

        const options = normalizeMatchOptions(msg.options);
        const key = matchOptionsKey(options);
        const queue = matchmakingQueues.get(key);

        if (queue && queue.length){
          // Нашёлся ожидающий с такими же настройками — сразу сводим пару.
          const partner = queue.shift();
          if (!queue.length) matchmakingQueues.delete(key);
          partner.searching = false;
          partner.searchKey = null;

          const room = createRoom(options);
          const tokenPartner = seatWithToken(room, 1, partner, resolvePlayer(partner.pendingAuthToken));
          const tokenSelf = seatWithToken(room, 2, ws, resolvePlayer(msg.authToken));
          room.gameId = gameLog.startGame(room);

          const snapshot = room.match.getSnapshot();
          send(partner, { type:'match-found', code: room.code, seat: 1, token: tokenPartner, snapshot, playerNames: room.playerNames });
          send(ws, { type:'match-found', code: room.code, seat: 2, token: tokenSelf, snapshot, playerNames: room.playerNames });
          return;
        }

        // Пары нет — встаём в очередь ждать следующего с такими же опциями.
        // authToken запоминаем на ws — сведение пары происходит в момент,
        // когда сообщение find-match присылает уже ВТОРОЙ игрок, поэтому
        // ник первого (partner) нужно достать из его собственного запроса,
        // сохранённого на его сокете, а не из текущего msg.
        ws.searching = true;
        ws.searchKey = key;
        ws.pendingAuthToken = msg.authToken || null;
        if (!matchmakingQueues.has(key)) matchmakingQueues.set(key, []);
        matchmakingQueues.get(key).push(ws);
        send(ws, { type:'searching' });
        return;
      }

      if (msg.type === 'cancel-find'){
        if (!ws.searching) return send(ws, { type:'error', reason:'not-searching' });
        removeFromQueue(ws);
        send(ws, { type:'search-cancelled' });
        return;
      }

      if (msg.type === 'list-rooms'){
        const list = [];
        for (const room of rooms.values()){
          const entry = roomListEntry(room);
          if (entry) list.push(entry);
        }
        send(ws, { type:'room-list', rooms: list });
        return;
      }

      if (msg.type === 'spectate-room'){
        if (ws.roomCode) return send(ws, { type:'error', reason:'already-in-room' });
        const room = getRoom(msg.code);
        if (!room) return send(ws, { type:'error', reason:'room-not-found' });
        if (!room.isPublic) return send(ws, { type:'error', reason:'room-not-public' });
        room.spectators.add(ws);
        ws.roomCode = room.code;
        ws.seat = null; // зритель не занимает место — отличает его от игрока в обработчиках ниже
        ws.spectating = true;
        send(ws, { type:'spectate-joined', code: room.code, snapshot: room.match.getSnapshot(), playerNames: room.playerNames, vsBot: room.vsBot });
        return;
      }

      if (msg.type === 'leave-room'){
        // Немедленный, явный уход — в отличие от обрыва связи (ws close),
        // не ждёт reconnectGraceMs: место сразу же становится свободным,
        // чтобы по тому же коду мог зайти другой игрок (см. README, шаг 10).
        if (ws.spectating){
          const room = getRoom(ws.roomCode);
          if (room) room.spectators.delete(ws);
          ws.roomCode = null; ws.seat = null; ws.spectating = false;
          send(ws, { type:'left-room' });
          return;
        }
        const room = getRoom(ws.roomCode);
        if (!room || !ws.seat) return send(ws, { type:'error', reason:'not-in-room' });
        const seat = ws.seat;
        clearSeatGraceTimer(room, seat);
        room.seats[seat] = null;
        room.tokens[seat] = null;
        room.rematchVotes.delete(seat);
        // Соперник ушёл — любой висящий запрос на отмену хода больше не
        // имеет смысла: либо ушёл тот, кто просил (спрашивать уже некого),
        // либо тот, кто должен был согласиться (некому подтвердить).
        room.pendingUndo = null;
        ws.roomCode = null; ws.seat = null;
        send(ws, { type:'left-room' });
        broadcastRoom(room, { type:'opponent-left', seat });
        if (!room.seats[1] && !room.seats[2]) armEmptyTimer(room);
        return;
      }

      if (msg.type === 'reconnect'){
        if (ws.roomCode) return send(ws, { type:'error', reason:'already-in-room' });
        const room = getRoom(msg.code);
        const seat = msg.seat;
        if (!room || (seat !== 1 && seat !== 2)) return send(ws, { type:'error', reason:'reconnect-failed' });
        if (!room.tokens[seat] || room.tokens[seat] !== msg.token) return send(ws, { type:'error', reason:'reconnect-failed' });
        if (room.seats[seat]) return send(ws, { type:'error', reason:'seat-occupied' });

        clearSeatGraceTimer(room, seat);
        disarmEmptyTimer(room);
        room.seats[seat] = ws;
        ws.roomCode = room.code;
        ws.seat = seat;
        // Ник/учётку переподключившегося не трогаем, если он не прислал
        // новый authToken (например, просто открыл вкладку заново, не
        // логинясь повторно) — иначе бот/гостевые места теряли бы имя при
        // реконнекте. Итоговые значения для лога партии фиксируются позже,
        // при её завершении (см. gameLog.finish в 'move'/'end' ниже).
        const reconnectedPlayer = resolvePlayer(msg.authToken);
        if (reconnectedPlayer){
          room.playerNames[seat] = reconnectedPlayer.nickname;
          room.playerUserIds[seat] = reconnectedPlayer.id;
        }

        send(ws, { type:'reconnected', code: room.code, seat, token: room.tokens[seat], snapshot: room.match.getSnapshot(), vsBot: room.vsBot, playerNames: room.playerNames });
        const otherSeat = seat === 1 ? 2 : 1;
        send(room.seats[otherSeat], stateMessage(room, { note: 'opponent-reconnected', seat }));
        return;
      }

      const room = getRoom(ws.roomCode);
      if (!room || !ws.seat) return send(ws, { type:'error', reason:'not-in-room' });

      if (msg.type === 'move'){
        if (room.pendingUndo) return send(ws, { type:'error', reason:'undo-pending' });
        const result = room.match.applyMove(ws.seat, msg.x, msg.y);
        if (!result.ok) return send(ws, { type:'error', reason: result.reason });
        recordMoveInLog(room, ws.seat, msg.x, msg.y, result);
        broadcastRoom(room, stateMessage(room, { lastMove: { x: msg.x, y: msg.y, player: ws.seat }, extraTurn: result.extraTurn }));
        maybeTriggerBotMove(room);
        return;
      }

      if (msg.type === 'end'){
        const result = room.match.endNow();
        if (!result.ok) return send(ws, { type:'error', reason: result.reason });
        cancelBotSearch(room); // A10: после gameOver ход бота не применяется
        gameLog.finish(room, result.winner, result.scores, 'manual');
        broadcastRoom(room, stateMessage(room));
        return;
      }

      if (msg.type === 'request-undo'){
        if (room.pendingUndo) return send(ws, { type:'error', reason:'undo-already-requested' });
        const seat = ws.seat;
        if (!room.match.canUndoLastMove()){
          const snap = room.match.getSnapshot();
          const reason = !snap.rules.undoAllowed ? 'undo-disabled' : (snap.gameOver ? 'game-over' : 'nothing-to-undo');
          return send(ws, { type:'error', reason });
        }
        // Отменить можно только СВОЙ последний ход — иначе это уже не
        // "я ошибся", а попытка отменить ход соперника без его на то воли.
        if (room.match.lastMoverSeat() !== seat) return send(ws, { type:'error', reason:'not-your-move-to-undo' });

        if (room.vsBot){
          // У бота нет своей воли, которую можно спросить — согласие
          // выставляется автоматически, отмена применяется сразу же.
          applyApprovedUndo(room);
          return;
        }

        const opponentSeat = seat === 1 ? 2 : 1;
        const opponentWs = room.seats[opponentSeat];
        if (!opponentWs) return send(ws, { type:'error', reason:'opponent-unavailable' });

        room.pendingUndo = { seat };
        send(opponentWs, { type:'undo-requested', seat });
        send(ws, { type:'undo-requested', seat });
        return;
      }

      if (msg.type === 'undo-approve'){
        if (!room.pendingUndo) return send(ws, { type:'error', reason:'no-pending-undo' });
        if (ws.seat === room.pendingUndo.seat) return send(ws, { type:'error', reason:'cannot-approve-own-request' });
        applyApprovedUndo(room);
        return;
      }

      if (msg.type === 'undo-decline'){
        if (!room.pendingUndo) return send(ws, { type:'error', reason:'no-pending-undo' });
        if (ws.seat === room.pendingUndo.seat) return send(ws, { type:'error', reason:'cannot-decline-own-request' });
        const requesterSeat = room.pendingUndo.seat;
        room.pendingUndo = null;
        send(room.seats[requesterSeat], { type:'undo-declined', seat: requesterSeat });
        return;
      }

      if (msg.type === 'rematch'){
        if (!room.match.getSnapshot().gameOver) return send(ws, { type:'error', reason:'game-not-over' });
        const seat = ws.seat;
        room.rematchVotes.add(seat);
        const opponentSeat = seat === 1 ? 2 : 1;
        const opponentWs = room.seats[opponentSeat];
        // Против бота, или если за столом больше никого нет (второе место
        // свободно — соперник ушёл), согласие второй стороны спрашивать не
        // у кого, реванш стартует сразу по одному запросу.
        const bothReady = room.vsBot || !opponentWs || room.rematchVotes.has(opponentSeat);
        if (bothReady) startRematch(room);
        else send(opponentWs, { type:'rematch-requested', seat });
        return;
      }

      send(ws, { type:'error', reason:'unknown-message-type' });
    });

    ws.on('close', () => {
      removeFromQueue(ws);
      const room = getRoom(ws.roomCode);
      if (!room) return;
      if (ws.spectating){
        room.spectators.delete(ws);
        return;
      }
      if (ws.seat && room.seats[ws.seat] === ws){
        const seat = ws.seat;
        room.seats[seat] = null;
        room.rematchVotes.delete(seat);
        // Как и при явном leave-room — висящий запрос на отмену теряет
        // смысл, если кто-то из двоих внезапно отвалился по сети.
        room.pendingUndo = null;
        broadcastRoom(room, { type:'opponent-disconnected', seat, graceMs: reconnectGraceMs });
        armSeatGraceTimer(room, seat, () => {
          broadcastRoom(room, { type:'opponent-left', seat });
          if (!room.seats[1] && !room.seats[2]) armEmptyTimer(room);
        });
      }
    });
  });

  // A10: корректная остановка — снимаем все поиски бота и завершаем потоки
  // пула, чтобы после остановки сервера не оставалось worker_threads.
  function closeBotPool(){
    for (const room of rooms.values()) room.botTicket = null;
    return botPool ? botPool.close() : Promise.resolve();
  }
  httpServer.on('close', () => { closeBotPool().catch(() => {}); });

  function close(){
    return new Promise((resolve) => {
      for (const client of wss.clients) { try { client.terminate(); } catch (_) {} }
      wss.close(() => {
        if (httpServer.listening) httpServer.close(() => resolve());
        else resolve();
      });
    }).then(() => closeBotPool());
  }

  return { httpServer, wss, rooms, db, auth, gameLog, training, dbPath, botPool, closeBotPool, close };
}

if (require.main === module){
  const PORT = process.env.PORT || 8080;
  const server = createServer();
  const { httpServer } = server;
  // A10: по SIGINT/SIGTERM завершаем потоки поиска бота вместе с сервером.
  let stopping = false;
  const shutdown = (sig) => {
    if (stopping) return;
    stopping = true;
    console.log(`${sig}: остановка сервера...`);
    server.close().then(() => process.exit(0), () => process.exit(1));
    setTimeout(() => process.exit(1), 5000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  httpServer.listen(PORT, () => {
    console.log(`Tochki multiplayer server: http://localhost:${PORT}`);
    console.log('Один игрок создаёт комнату и получает код, второй присоединяется по этому коду.');
  });
}

module.exports = { createServer };
